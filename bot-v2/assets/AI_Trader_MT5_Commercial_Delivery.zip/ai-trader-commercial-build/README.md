# AI Trader MT5 commercial build

`AI_Trader_MT5_Licensed.ex5` was compiled successfully from the vendor-only
MQL5 source on 2026-10-18. It is not installed in a terminal and has never
been started by this build process.

The file fails closed: it requires a valid online licence tied to the current
MT5 account number and broker server. New installations also have
`EnableTrading=false` by default. Do not distribute the matching `.mq5` source.

Before any customer installation, deploy the Supabase migration and the
`crm-license-gateway` function, configure the server-only secrets, then make a
test licence for a demo account. The public checkout remains unavailable for
payments until CoinGate is configured with a newly generated API credential.

SHA-256:

`c54cc5e38d091fbdcd9d3c3f65bb1e99163b8cdfc87e788df87a969da370c1b5`
